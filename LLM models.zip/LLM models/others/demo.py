import json
import openai

openai.api_key ="sk-proj-KThBjnHkYqwkQd8hMIkPT3BlbkFJftdddZFmpLm9Nq5KNcXp"

# Example JSON data
json_data = {
    "name": "John Doe",
    "age": 30,
    "email": "john.doe@example.com",
    "occupation": "Software Developer"
}

json_string = json.dumps(json_data, indent=4)

# Change request
change_request = "Update the email to john.doe@newdomain.com"

# Combine JSON data and change request into a prompt
prompt = f"Given the following JSON data:\n\n{json_string}\n\n{change_request}\n\nReturn the updated JSON data."

# Make the API request
response = openai.ChatCompletion.create(
    model="text-davinci-003",
    prompt=prompt,
    max_tokens=200,
    temperature=0
)

# Parse the updated JSON
updated_json_string = response.choices[0].text.strip()
updated_json_data = json.loads(updated_json_string)

print(updated_json_data)
