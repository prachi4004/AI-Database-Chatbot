from dotenv import load_dotenv
from sqlalchemy import create_engine, Column, Integer, String, Date
from sqlalchemy.orm import declarative_base, sessionmaker
from langchain_openai import OpenAI
from langchain_experimental.sql import SQLDatabaseChain
from langchain_community.utilities import SQLDatabase

# Load environment variables
load_dotenv()

# Define the database URI using Windows Authentication
database_uri = (
    "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};"
    "SERVER=INVPT-L138;DATABASE=BikeStore;Trusted_Connection=yes;"
)

# Create the SQLAlchemy engine
engine = create_engine(database_uri)

# Define the ORM model
Base = declarative_base()

class Order(Base):
    __tablename__ = 'sales.orders'
    order_id = Column(Integer , primary_key=True)
    customer_id = Column(Integer)
    order_status = Column(Integer)
    order_date = Column(Date)
    required_date = Column(Date)
    shipped_date = Column(Date)
    store_id = Column(String)
    staff_id = Column(String)

# Create the tables in the database
Base.metadata.create_all(engine)

# Create a session
Session = sessionmaker(bind=engine)
session = Session()

# Example query to test the connection
orders = session.query(Order).all()
print("Printing orders")
for order in orders:
    print(f"{order.order_id}, {order.customer_id}, {order.order_status}, {order.order_date}, {order.required_date}, {order.shipped_date}, {order.store_id}, {order.staff_id}")
print(orders)

# Close the session
session.close()

# Initialize the OpenAI language model
llm = OpenAI(temperature=0)

# Create the SQLDatabase instance
db = SQLDatabase(engine)

# Create the SQL agent using from_llm class method
agent = SQLDatabaseChain.from_llm(llm=llm, db=db, verbose=True)

# Run a query
response = agent.invoke({"query": "What is the custumer id of order id 8"})
print(response)
