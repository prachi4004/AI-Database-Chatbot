from dotenv import load_dotenv
#from langchain import OpenAI, SQLDatabase, SQLDatabaseChain
from langchain_community.llms import OpenAI
from langchain_community.utilities import SQLDatabase
from langchain_experimental.sql import SQLDatabaseChain

load_dotenv()
dburi="sqlite:///academy/academy.sql"
db=SQLDatabase.from_uri(dburi)
llm=OpenAI(temperature=0)    #as we do not want any creativity
db_chain=SQLDatabaseChain(llm=llm,database=db,verbose=True)   #true so that we can see step by step

db_chain.run("Describe the database?")
#db_chain.run("Describe the orders table")
