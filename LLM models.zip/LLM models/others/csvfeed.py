from dotenv import load_dotenv
#from langchain import OpenAI
from langchain_openai import OpenAI
#from langchain_experimental.agents.create_csv_agent import CSVLoader
from langchain_community.document_loaders import CSVLoader
load_dotenv()

filepath = "academy/customers.csv"
loader = CSVLoader(filepath)
data = loader.load()
#print(data)

llm = OpenAI(temperature=0)

#from langchain.agents import create_csv_agent

from langchain_experimental.agents import create_csv_agent
agent = create_csv_agent(llm, filepath, verbose=True, allow_dangerous_code=True)

agent.run("Give me the custumer Id's of all the customers living in Chile")
agent.run("Give me the custumer Id's of all the customers living in Oman")
#response = agent.run("Give me the customer Id's of all the customers living in Oman")
#print(response)

#response = agent.invoke({"input": "Give me the customer Id's of all the customers living in Chile"})
response = agent.invoke({"input": "Give me the customer name of all the customers living in Chile"})

print(response)
