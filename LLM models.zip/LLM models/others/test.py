from dotenv import load_dotenv
#from langchain import OpenAI, SQLDatabase, SQLDatabaseChain
from langchain_community.llms import OpenAI
from langchain_community.utilities import SQLDatabase
from langchain_experimental.sql import SQLDatabaseChain

load_dotenv()
conn_str = "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=BikeStore;Trusted_Connection=yes;"
db = SQLDatabase.from_uri(conn_str)
llm=OpenAI(temperature=0)    #as we do not want any creativity
db_chain=SQLDatabaseChain(llm=llm,database=db,verbose=True)   #true so that we can see step by step

db_chain.run("Describe the database?")
