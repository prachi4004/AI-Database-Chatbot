from langchain_openai import OpenAI
from langchain_community.utilities import SQLDatabase                
from langchain_experimental.sql import SQLDatabaseChain
from dotenv import load_dotenv
import os
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')  # The API key is an environment variable
DB_URI =  "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=AdventureWorks2019;Trusted_Connection=yes;"
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

db = SQLDatabase.from_uri(DB_URI)
llm = OpenAI(temperature=0)  # Temperature is kept 0 as we do not want creativity in our answers

db_chain = SQLDatabaseChain.from_llm(llm=llm, db=db, verbose=True)  # Verbose is kept true so that we can see the SQL QUERY that AI would use on our database

# Define relevant keywords
relevant_keywords = ["customer", "order", "product", "staff", "employee", "worker", "sales", "HumanResources", "person", "production", "purchasing","customers","jobTitle","businessEntity","business","national id","customerid"]
# Define replacements
replacements = {
    "name": "first name",
    "firstnames": "first name"
}
def is_relevant_question(question):
    return any(keyword in question.lower() for keyword in relevant_keywords)

def preprocess_question(question):
    for key, value in replacements.items():
        question = question.lower().replace(key, value)
    return question

def run_query_with_fallback(ques):          #fallback mechanism
    try:
        # Attempt to run the query on the main tables
        response = db_chain.run(ques + ". In the query remove the [] brackets, consider the entire data, print the entire data that is asked and answer only from the database do not make up any data. The answer should definitely be present in the database. If the SQL query is invalid or throws an error then give the output - 'An error occurred.' If the SQL query returns no data then give the output - 'No such data found.' If the question is not enough to form a query then give the output - 'Enough data not provided to form a query.' Now if the input says member, custumer, customer, costomer or user take it as customers. Now if the input says staff, staffs, employee, worker or workers take it as staff. The Database has Schema which includes HumanResources, person, production, purchasing and sales.If a question which is not relevant to the data provided in the database is asked in the first line then say -Irrelevant question ")
        # Check if response indicates no data found
        if 'No such data found' in response:
            raise ValueError('No data found in main tables, trying view table')
        return response
    except (SQLAlchemyError, ValueError) as e:
        # If an error occurs or no data is found, attempt to query the view table
        try:
            view_response = db_chain.run(ques + ". Convert this natural language instruction to an SQL statement, In the query remove the [] brackets, go to Views instead of tables")
            return view_response
        except SQLAlchemyError as view_e:
            return f"An error occurred in both main and view tables: {view_e}"

print("Press quit to end the chat")
while True:
    ques = input("Ask a question:  ")
    if ques.lower() == "quit":
        break
    if not is_relevant_question(ques):
        print("Irrelevant question, please try again")
        continue
    ques = preprocess_question(ques)  # Preprocess the question
    ##Seperating the update and deletion statements for easier application of restrictions if applicable
    if "update" in ques.lower() or "replace" in ques.lower() or "change" in ques.lower():
        response = db_chain.run(ques + ". Convert this natural language instruction to an SQL UPDATE statement, In the query remove the [] brackets")
    elif "remove" in ques.lower() or "delete" in ques.lower() or "deletion" in ques.lower() or "deletes" in ques.lower():
        response = db_chain.run(ques + ". Convert this natural language instruction to an SQL DELETE statement, In the query remove the [] brackets")
    else:
        response = run_query_with_fallback(ques)
    print(response)
