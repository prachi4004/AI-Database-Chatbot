from langchain_openai import OpenAI
from langchain_community.utilities import SQLDatabase                
from langchain_experimental.sql import SQLDatabaseChain
from dotenv import load_dotenv
import os
from sqlalchemy.exc import SQLAlchemyError

load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
DB_URL =  "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=AdventureWorks2019;Trusted_Connection=yes;"
## Change the Server Name and Database name above,The URI is MSSQL specific
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

db = SQLDatabase.from_uri(DB_URL)
llm = OpenAI(temperature=0)

db_chain = SQLDatabaseChain(llm=llm, database=db, verbose=True)
print("Press quit to end the chat")
while(True):
    ques=input("Ask a question:  ")
    if ques.lower()=="quit":
        break
    try:
        db_chain.run(ques+"In the query remove the [] brackets,Consider the entire data,Print the entire data that is asked and answer only from the database do not makeup any data.The answer should definately be present in the database.If the Sql Query is invalid or throws an error then give the output -An error occured.If the SQL Query returns no data then give the output -No such Data found"
                     "If the question is not enough to form a query then give the output -Enough data not provided to form a query."
                     "Now if the input says member,custumer,customer,costomer or user take it as customers"
                     "Now if the input says staff,staffs,employee,worker or workers take it as staff"
                     "The Database has Schema which includes HumanResources,person,production,purchasing and sales"
                     "HumanResources has tables ")
    except SQLAlchemyError as e:
        print ( f"An error occurred: {e}")
    

    



