from langchain_openai import OpenAI
from langchain_community.utilities import SQLDatabase                
from langchain_experimental.sql import SQLDatabaseChain
from dotenv import load_dotenv
import os
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')               #The API key is an environment variable
DB_URI =  "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=AdventureWorks2019;Trusted_Connection=yes;"
## Change the Server Name and Database name above, The URI is MSSQL(SQL Server) specific
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

db = SQLDatabase.from_uri(DB_URI)
llm = OpenAI(temperature=0)   #temperature is kept 0 as we do not want creativity in our answers

db_chain = SQLDatabaseChain.from_llm(llm=llm, db=db, verbose=True)      #verbose is kept true so that we can see the SQL QUERY that AI would use on our database
##The flask API should be able to give the input and should also be able to take the output from these statements to the website
print("Press quit to end the chat")
while True:
    ques = input("Ask a question:  ")
    if ques.lower() == "quit":
        break
    try:
        if "update" in ques.lower() or "replace" in ques.lower() or "change" in ques.lower():
             response = db_chain.run(ques+". Convert this natural language instruction to an SQL UPDATE statement,In the query remove the [] brackets")
        elif "name" in ques.lower() or "firstname" in ques.lower() or "middlename" in ques.lower() or "lastname" in ques.lower():
             response = db_chain.run(ques+". Convert this natural language instruction to an SQL statement,In the query remove the [] brackets,go to [HumanResources].[vEmployee]")
        else:
             response = db_chain.run(ques + ". In the query remove the [] brackets, consider the entire data, print the entire data that is asked and answer only from the database do not make up any data. The answer should definitely be present in the database. If the SQL query is invalid or throws an error then give the output - 'An error occurred.' If the SQL query returns no data then give the output - 'No such data found.'"     
                                      "If the question is not enough to form a query then give the output -Enough data not provided to form a query."
                                      "Now if the input says member,custumer,customer,costomer or user take it as customers"
                                      "Now if the input says staff,staffs,employee,worker or workers take it as staff"
                                      "The Database has Schema which includes HumanResources,person,production,purchasing and sales"
                                      "If name of an employee is asked then go to the view table")
        print(response)
    except SQLAlchemyError as e:
        print ( f"An error occurred: {e}")
