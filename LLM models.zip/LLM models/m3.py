from langchain_openai import OpenAI
from langchain_community.utilities import SQLDatabase
from langchain_experimental.sql import SQLDatabaseChain
from dotenv import load_dotenv
import os
from sqlalchemy import create_engine, text, inspect
from sqlalchemy.exc import SQLAlchemyError

# Load environment variables
load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
DB_URI = "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=AdventureWorks2019;Trusted_Connection=yes;"
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# Initialize database connection and OpenAI
db = SQLDatabase.from_uri(DB_URI)
llm = OpenAI(temperature=0, model="gpt-4.0")
db_chain = SQLDatabaseChain.from_llm(llm=llm, database=db, verbose=True)
engine = create_engine(DB_URI)

# Function to extract relevant keywords (tables, columns) from user input
def extract_keywords_from_input(input_text):
    prompt = f"Extract relevant table and column names from the following text: '{input_text}'"
    response = llm(prompt)
    return response.strip()

# Function to dynamically query schema based on extracted keywords
def query_schema(keywords):
    inspector = inspect(engine)
    schema_info = {}
    for table_name in inspector.get_table_names():
        columns = [col['name'] for col in inspector.get_columns(table_name)]
        if any(keyword in table_name or keyword in columns for keyword in keywords.split()):
            schema_info[table_name] = columns
    return schema_info

# Function to generate and execute SQL query based on schema info and user input
def generate_and_execute_sql_query(input_text, schema_info):
    # Use schema_info to determine the table and columns to query
    # Generate SQL query using the determined table and columns
    table_name = list(schema_info.keys())[0]  # Simplified for example; handle multiple tables as needed
    columns = schema_info[table_name]
    prompt = f"Generate an SQL query based on the input: '{input_text}' for table '{table_name}' with columns {', '.join(columns)}"
    sql_query = llm(prompt).strip()
    
    try:
        with engine.connect() as connection:
            result = connection.execute(text(sql_query))
            return result.fetchall()
    except SQLAlchemyError as e:
        return f"An error occurred: {e}"

# Main interaction loop
print("Press quit to end the chat")
while True:
    ques = input("Ask a question: ")
    if ques.lower() == "quit":
        break
    
    # Extract keywords and query schema dynamically
    keywords = extract_keywords_from_input(ques)
    schema_info = query_schema(keywords)
    
    # Generate and execute SQL query
    response = generate_and_execute_sql_query(ques, schema_info)
    
    print(response)
