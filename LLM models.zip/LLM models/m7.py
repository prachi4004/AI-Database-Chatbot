from langchain_openai import OpenAI
from langchain_community.utilities import SQLDatabase
from langchain_experimental.sql import SQLDatabaseChain
from dotenv import load_dotenv
import os
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.exc import SQLAlchemyError

load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')  # The API key is an environment variable
DB_URI = "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=AdventureWorks2019;Trusted_Connection=yes;"
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

db = SQLDatabase.from_uri(DB_URI)
llm = OpenAI(temperature=0)  # Temperature is kept 0 as we do not want creativity in our answers

db_chain = SQLDatabaseChain.from_llm(llm=llm, db=db, verbose=True)  # Verbose is kept true so that we can see the SQL QUERY that AI would use on our database

# Define replacements
replacements = {
    "name": "full name",
    "firstnames": "first name"
}

def preprocess_question(question):
    for key, value in replacements.items():
        question = question.lower().replace(key, value)
    return question

def get_table_names():
    engine = create_engine(DB_URI)
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    return tables

def run_query_with_fallback(ques):  # fallback mechanism
    tables = get_table_names()
    
    tables_prompt = "The database has the following tables: " + ", ".join(tables) + "."
    
    try:
        # Attempt to run the query on the main tables
        response = db_chain.run(tables_prompt + " " + ques + ". In the query remove the [] brackets, consider the entire data, print the entire data that is asked and answer only from the database do not make up any data. The answer should definitely be present in the database. If the SQL query is invalid or throws an error then give the output - 'An error occurred.' If the SQL query returns no data then give the output - 'No such data found.' If the question is not enough to form a query then give the output - 'Enough data not provided to form a query.'. Never use the AWBuildVersion table or DatabaseLog or ErrorLog Table to form an SQL Query.Now if the input says member, custumer, customer, costomer or user take it as customers. Now if the input says staff, staffs, employee, worker or workers take it as staff. If a question which is not relevant to the data provided in the database is asked in the first line then say -Irrelevant question")
        # Check if response indicates no data found
        if 'No such data found' in response:
            raise ValueError('No data found in main tables, trying view table')
        return response
    except (SQLAlchemyError, ValueError) as e:
        # If an error occurs or no data is found, attempt to query the view table
        try:
            view_response = db_chain.run(tables_prompt + " " + ques + ". Convert this natural language instruction to an SQL statement, In the query remove the [] brackets, go to Views instead of tables.Never use the AWBuildVersion table or DatabaseLog or ErrorLog Table to form an SQL Query.")
            return view_response
        except SQLAlchemyError as view_e:
            return f"An error occurred in both main and view tables: {view_e}"

print("Press quit to end the chat")
while True:
    ques = input("Ask a question:  ")
    if ques.lower() == "quit":
        break
    ques = preprocess_question(ques)  # Preprocess the question
    # Separating the update and deletion statements for easier application of restrictions if applicable
    if "update" in ques.lower() or "replace" in ques.lower() or "change" in ques.lower():
        response = db_chain.run(ques + ". Convert this natural language instruction to an SQL UPDATE statement, In the query remove the [] brackets.Never use the AWBuildVersion table or DatabaseLog or ErrorLog Table to form an SQL Query.")
    elif "remove" in ques.lower() or "delete" in ques.lower() or "deletion" in ques.lower() or "deletes" in ques.lower():
        response = db_chain.run(ques + ". Convert this natural language instruction to an SQL DELETE statement, In the query remove the [] brackets.Never use the AWBuildVersion table or DatabaseLog or ErrorLog Table to form an SQL Query.")
    else:
        response = run_query_with_fallback(ques)
    print(response)
