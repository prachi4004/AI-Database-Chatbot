from langchain_openai import OpenAI
from langchain_community.utilities import SQLDatabase                
from langchain_experimental.sql import SQLDatabaseChain
from dotenv import load_dotenv
import os
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import create_engine, inspect, text

load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')  # The API key is an environment variable
DB_URI =  "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=AdventureWorks2019;Trusted_Connection=yes;"
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# Initialize the database and language model
db = SQLDatabase.from_uri(DB_URI)
llm = OpenAI(temperature=0)  # Temperature is kept 0 as we do not want creativity in our answers
db_chain = SQLDatabaseChain.from_llm(llm=llm, db=db, verbose=True)  # Verbose is kept true so that we can see the SQL QUERY that AI would use on our database

# Define a function to get table names and column names
def get_table_names():
    engine = create_engine(DB_URI)
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    return tables

tables = get_table_names()
    
tables_prompt = "The database has the following tables: " + ", ".join(tables) + "."

# Define the chatbot context once
context = f"The database schema includes the following tables and columns:\n{tables_prompt}\n\n"

# Create a chatbot class to handle session-based interaction
class Chatbot:
    def __init__(self, db_chain, context):
        self.db_chain = db_chain
        self.context = context

    def ask(self, question):
        prompt = self.context + question
        
        if "update" in question.lower() or "replace" in question.lower() or "change" in question.lower():
            #response = self.db_chain.run(prompt + ". Convert this natural language instruction to an SQL UPDATE statement, In the query remove the [] brackets")
            response = db_chain.run(prompt + ". Convert this natural language instruction to an SQL UPDATE statement, In the query remove the [] brackets.The new value should have the same punctuation and capital letters.If you do not know the answer of the the question say I don't know. Never use the AWBuildVersion table to form an SQL Query.Never use the DatabaseLog table to form an SQL Query.  Never use the ErrorLog Table table to form an SQL Query. ")
           
        elif "remove" in question.lower() or "delete" in question.lower() or "deletion" in question.lower() or "deletes" in question.lower():
             response = db_chain.run(prompt + ". Convert this natural language instruction to an SQL DELETE statement, In the query remove the [] brackets.If you do not know the answer of the the question say I don't know.Never use the AWBuildVersion table, DatabaseLog or ErrorLog Table to form an SQL Query.")
            #response = self.db_chain.run(prompt + ". Convert this natural language instruction to an SQL DELETE statement, In the query remove the [] brackets")
        else:
            #response = self.db_chain.run(prompt + ". In the query remove the [] brackets, consider the entire data, print the entire data that is asked and answer only from the database do not make up any data. The answer should definitely be present in the database. If the SQL query is invalid or throws an error then give the output - 'An error occurred.' If the SQL query returns no data then give the output - 'No such data found.' If the question is not enough to form a query then give the output - 'Enough data not provided to form a query.' Now if the input says member, custumer, customer, costomer or user take it as customers. Now if the input says staff, staffs, employee, worker or workers take it as staff. The Database has Schema which includes HumanResources, person, production, purchasing and sales. If a question which is not relevant to the data provided in the database is asked in the first line then say -Irrelevant question ")
            response = self.db_chain.run(prompt +". In the query remove the [] brackets, consider the entire data,If you do not know the answer of the the question say I don't know.Never use the AWBuildVersion table to form an SQL Query, if you do say -I do not know.Never use the ErrorLog Table table to form an SQL Query, if you do say -I do not know.Never use the DatabaseLog table to form an SQL Query,if you do say -I do not know.Selct the top 10 values always when you use the select statement.Use in instead of = in your queries to represent all possible data. Print the entire data that is asked and answer only from the database do not make up any data. The answer should definitely be present in the database. If the question is not enough to form a query then give the output - 'Enough data not provided to form a query.'. The Database has Schema which includes HumanResources, person, production, purchasing and sales. If a question which is not relevant to the data provided in the database is asked in the first line then say -Irrelevant question")
        
        return response

# Initialize the chatbot with context
chatbot = Chatbot(db_chain, context)

print("Press quit to end the chat")
while True:
    ques = input("Ask a question:  ")
    if ques.lower() == "quit":
        break
    
    response = chatbot.ask(ques)
    print(response)
