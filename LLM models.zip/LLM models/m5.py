from langchain_openai import OpenAI
from langchain_community.utilities import SQLDatabase                
from langchain_experimental.sql import SQLDatabaseChain
from dotenv import load_dotenv
import os
from sqlalchemy import create_engine, inspect
from sqlalchemy.exc import SQLAlchemyError

load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')  # The API key is an environment variable
DB_URI = "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=AdventureWorks2019;Trusted_Connection=yes;"
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

db = SQLDatabase.from_uri(DB_URI)
llm = OpenAI(temperature=0)  # Temperature is kept 0 as we do not want creativity in our answers

db_chain = SQLDatabaseChain.from_llm(llm=llm, db=db, verbose=True)  # Verbose is kept true so that we can see the SQL QUERY that AI would use on our database

# Extracting database schema information for validation
engine = create_engine(DB_URI)
inspector = inspect(engine)

# def get_schema_info():
#     schema_info = {}
#     tables = inspector.get_table_names()
#     for table in tables:
#         columns = inspector.get_columns(table)
#         schema_info[table] = [column['name'] for column in columns]
#     return schema_info

# schema_info = get_schema_info()

# def is_valid_query(query):                  # To prevent hallucinations
#     for table in schema_info:
#         if table in query:
#             for column in schema_info[table]:
#                 if column in query:
#                     return True
#     return False

def run_query_with_fallback(ques):  # fallback mechanism to view the tables first and then also view the view table
    try:
        # Attempt to run the query on the main tables
        response = db_chain.run(ques + ". In the query remove the [] brackets, consider the entire data, print the entire data that is asked and answer only from the database do not make up any data.If you do not know the answer of the the question say I don't know.Selct the top 10 values always when you use the select statement.Use in instead of = in your queries to represent all possible data.Show all the data in the SQL result.The answer should definitely be present in the database. If the SQL query is invalid or throws an error then give the output - 'An error occurred.' If the SQL query returns no data then give the output - 'No such data found.' If the question is not enough to form a query then give the output - 'Enough data not provided to form a query.' Now if the input says member, custumer, customer, costomer or user take it as customers. Now if the input says staff, staffs, employee, worker or workers take it as staff. The Database has Schema which includes HumanResources, person, production, purchasing and sales.")
        # Validate query before executing
        # if not is_valid_query(response):
        #     return "The generated query is not valid based on the current database schema."
        # Check if response indicates no data found
        if 'No such data found' in response:
            raise ValueError('No data found in main tables, trying view table')
        return response
    except (SQLAlchemyError, ValueError) as e:
        # If an error occurs or no data is found, attempt to query the view table
        try:
            view_response = db_chain.run(ques + ". Convert this natural language instruction to an SQL statement, In the query remove the [] brackets, go to Views instead of tables.Selct the top 10 values always when you use the select statement.Use in instead of = in your queries to represent all possible data.If you do not know the answer of the the question say I don't know.Show all the data in the SQL result")
            # Validate query before executing
            # if not is_valid_query(view_response):
            #     return "The generated query is not valid based on the current database schema."
            return view_response
        except SQLAlchemyError as view_e:
            return f"An error occurred in both main and view tables: {view_e}"

print("Press quit to end the chat")
while True:
    ques = input("Ask a question:  ")
    if ques.lower() == "quit":
        break
    if "update" in ques.lower() or "replace" in ques.lower() or "change" in ques.lower():
        response = db_chain.run(ques + ". Convert this natural language instruction to an SQL UPDATE statement, In the query remove the [] brackets.Answer only from the database do not make up any data.If you do not know the answer of the the question say I don't know.")
    elif "remove" in ques.lower() or "delete" in ques.lower() or "deletion" in ques.lower() or "deletes" in ques.lower():
         response = db_chain.run(ques + ". Convert this natural language instruction to an SQL DELETE statement, In the query remove the [] brackets.Answer only from the database do not make up any data.If you do not know the answer of the the question say I don't know.")
    else:
        response = run_query_with_fallback(ques)
    print(response)
