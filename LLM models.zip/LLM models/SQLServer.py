#from langchain_community.llms import OpenAI
from langchain_openai import OpenAI
from langchain_community.utilities import SQLDatabase                
from langchain_experimental.sql import SQLDatabaseChain
from dotenv import load_dotenv
import os

load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
DB_URL =  "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=BikeStore;Trusted_Connection=yes;"
## Change the Server Name and Database name above
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

db = SQLDatabase.from_uri(DB_URL)
llm = OpenAI(temperature=0)

db_chain = SQLDatabaseChain(llm=llm, database=db, verbose=True)
print("Press quit to end the chat")
while(True):
    ques=input("Ask a question:  ")
    if ques.lower()=="quit":
        break
    db_chain.run(ques+"in the query remove the [] brackets,Consider the entire data, and answer only from the database do not makeup any data the answer should definately be present in the database.If the question is not enough to form a query then give the output -Enough data not provided to form a query.Now if the input says member,custumer,customer,costomer or user take it as customers")
    

    



