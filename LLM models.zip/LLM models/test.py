from langchain_openai import OpenAI
from langchain_community.utilities import SQLDatabase                
from langchain_experimental.sql import SQLDatabaseChain
from dotenv import load_dotenv
import os
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
DB_URL =  "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=AdventureWorks2019;Trusted_Connection=yes;"
## Change the Server Name and Database name above, The URI is MSSQL specific
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

db = SQLDatabase.from_uri(DB_URL)
llm = OpenAI(temperature=0)

db_chain = SQLDatabaseChain.from_llm(llm=llm, db=db, verbose=True)

# Create a direct engine connection to handle update commands
engine = create_engine(DB_URL)

def handle_update_command(command):
    try:
        with engine.connect() as connection:
            transaction = connection.begin()
            try:
                result = connection.execute(text(command))
                transaction.commit()
                return "Update successful."
            except:
                transaction.rollback()
                raise
    except SQLAlchemyError as e:
        return f"An error occurred: {e}"

print("Press quit to end the chat")
while True:
    ques = input("Ask a question:  ")
    if ques.lower() == "quit":
        break
    
    if "update" in ques.lower() or "replace" in ques.lower() or "change" in ques.lower():
        response = handle_update_command(ques)
    else:
        response = db_chain.run(ques + ". In the query remove the [] brackets, consider the entire data, print the entire data that is asked and answer only from the database do not make up any data. The answer should definitely be present in the database. If the SQL query is invalid or throws an error then give the output - 'An error occurred.' If the SQL query returns no data then give the output - 'No such data found.' If the question is not enough to form a query then give the output - 'Enough data not provided to form a query.' Now if the input says member, custumer, customer, costomer, or user take it as customers. Now if the input says staff, staffs, employee, worker, or workers take it as staff. The database has schemas which include HumanResources, person, production, purchasing, and sales.")
                                 
    print(response)
