from langchain_openai import OpenAI
from langchain_community.utilities import SQLDatabase                
from langchain_experimental.sql import SQLDatabaseChain
from dotenv import load_dotenv
import os
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

load_dotenv()
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
DB_URI =  "mssql+pyodbc:///?odbc_connect=DRIVER={SQL Server Native Client 11.0};SERVER=INVPT-L138;DATABASE=AdventureWorks2019;Trusted_Connection=yes;"
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# Create the database connection and introspect schema
engine = create_engine(DB_URI)
metadata = SQLDatabase.from_uri(DB_URI)

# Example function to get the schema information
def get_schema_info():
    schema_info = {}
    with engine.connect() as connection:
        result = connection.execute(text("SELECT TABLE_NAME, COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS"))
        for row in result:
            table, column = row
            if table not in schema_info:
                schema_info[table] = []
            schema_info[table].append(column)
    return schema_info

schema_info = get_schema_info()
print("Schema Information:", schema_info)  # For debugging

# llm = OpenAI(temperature=0)

# # Modify SQLDatabaseChain to use schema_info for context
# db_chain = SQLDatabaseChain.from_llm(llm=llm, db=metadata, verbose=True)

# def create_schema_prompt(schema_info):
#     schema_prompt = "The database schema is as follows:\n"
#     for table, columns in schema_info.items():
#         schema_prompt += f"Table {table}: columns {', '.join(columns)}\n"
#     return schema_prompt

# schema_prompt = create_schema_prompt(schema_info)

# print("Press quit to end the chat")
# while True:
#     ques = input("Ask a question:  ")
#     if ques.lower() == "quit":
#         break
#     try:
#         if "update" in ques.lower() or "replace" in ques.lower() or "change" in ques.lower():
#             prompt = schema_prompt + "\nConvert the following natural language instruction to an SQL UPDATE statement: " + ques + ". In the query remove the [] brackets"
#             response = db_chain.run(prompt)
#         else:
#             prompt = schema_prompt + "\n" + ques + ". In the query remove the [] brackets, consider the entire data, print the entire data that is asked and answer only from the database do not make up any data. The answer should definitely be present in the database. If the SQL query returns no data then give the output - 'No such data found.' If the question is not enough to form a query then give the output - 'Enough data not provided to form a query.'"
#             response = db_chain.run(prompt)
#         print(response)
#     except SQLAlchemyError as e:
#         print(f"An error occurred: {e}")
